# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Blog::Application.config.secret_token = 'ca631c0174413801565c829bcbcaabab9c1c465b353a7d584d0f4cc0660e897c93d998e5dd08e2e45f11e94f829353bf4e5ac665eecaac75b68df161800440e0'
