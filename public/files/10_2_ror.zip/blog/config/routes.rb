Blog::Application.routes.draw do
  root :to => "posts#index"
	resources :posts do
		resources :comments
	end
	
	# Authlogic routes
  resource :login, :to => "user_sessions#new"
  resource :logout, :to => "user_sessions#destroy"
  resource :register, :to => "users#new"
  resource :account, :controller => 'users'
  resources :users
  resource :user_session
  match 'profiles/:id' => 'users#profile'
	
end
