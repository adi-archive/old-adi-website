class User < ActiveRecord::Base
  acts_as_authentic

  has_many :comments
  has_many :posts

  def self.find_by_login_or_email(login)
    User.find_by_email(login) || User.find_by_login(login)
  end
  
  def name
    self.email
  end
end