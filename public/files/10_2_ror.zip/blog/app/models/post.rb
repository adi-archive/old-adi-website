class Post < ActiveRecord::Base
	validates :title, :presence => true, :length => {:minimum => 5, :maximum => 150}
	validates :content, :presence => true, :length => {:minimum => 10, :maximum => 1000}
	has_many :comments, :dependent => :destroy
	belongs_to :user

end
