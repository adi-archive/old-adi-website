#gem install json
#gem install gchartrb

require 'rubygems'
require 'net/http'
require 'json'
require 'google_chart'

def twitter_search(query, search_day = "")
  base_url = "http://search.twitter.com/search.json"
  url = "#{base_url}?q=#{URI.encode(query)}&rpp=100&since=#{search_day}&until=#{search_day}"
  response_data = Net::HTTP.get_response(URI.parse(url)).body
  formatted_response = JSON.parse(response_data)
  return formatted_response["results"]
end

smiles, frowns = [],[]
days = 60*60*24

14.downto(1) { |i|
  search_day = (Time.now - i * days).strftime("%Y-%m-%d")
  search_results = twitter_search(':) OR :(', search_day)
  smiles << (search_results.select { |result| result["text"] =~  /\)/ }).size
  frowns << (search_results.select { |result| result["text"] =~  /\(/ }).size
}

min, max = (smiles + frowns).min, (smiles + frowns).max

GoogleChart::LineChart.new('320x200', "Twitter Mood", false) do |lc|
     lc.data "Smiles", smiles, '33CC66' #hex color code
     lc.data "Frowns", frowns, 'CC0033'
     lc.show_legend = true
     lc.axis :y, :range => [min,max], :font_size => 16
     lc.axis :x, :labels => ["",  "7 days ago", "today"]
     puts lc.to_url
     #note they don't add up to 100 :P
end