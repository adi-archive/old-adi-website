require 'rubygems'
require 'mechanize'

a = Mechanize.new { |agent|
    agent.user_agent_alias = 'Mac Safari'
  }
page = a.get("https://wind.columbia.edu/login?destination=https%3A%2F%2Fcourseworks%2Ecolumbia%2Eedu%2Fcms%2Fwind%2Flogin%2Ecfm%3Fskinbutton='+s'")
login_form = page.forms.first
#login_form.fields.each { |f| puts f.name }

unless ARGV[0] && ARGV[1]
  puts "Args not entered. Terminating."
  exit
end

login_form['username'] = ARGV[0]
login_form['password'] = ARGV[1]
page = login_form.click_button
body_text = page.body.to_s

something = false
if body_text.match(/d2.gif/)
  puts "Discussion board post made!"
  something = true
end
if body_text.match(/g2.gif/)
  puts "Grades up!!"
  something = true
end
if body_text.match(/a2.gif/)
  puts "Assignment posted."
  something = true
end
puts "Nothing up yet." unless something