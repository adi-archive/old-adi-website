1.upto(9) { |x| print x }

#print vs puts