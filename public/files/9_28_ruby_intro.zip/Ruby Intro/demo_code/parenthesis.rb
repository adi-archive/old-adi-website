def f(a)
  a + 4 #DON'T NEED TO RETURN
end

f(3+2) * 2
f (3+2) * 2