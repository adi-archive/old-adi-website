x, y = 1, 2
x, y = y, x