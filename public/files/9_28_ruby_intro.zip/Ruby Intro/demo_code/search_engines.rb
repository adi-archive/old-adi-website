#EXAMPLE 1
search_engines = %w[Google Yahoo Bing]
search_engines.map do |engine|
  "http://www." + engine.downcase + ".com"
end
search_engines

#EXAMPLE 2
search_engines = %w[Google Yahoo Bing]
search_engines = search_engines.map do |engine|
  "www." + engine.downcase! + ".com"
end
