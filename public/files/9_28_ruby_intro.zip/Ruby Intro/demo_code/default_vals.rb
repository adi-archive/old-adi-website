def multiply(x, y = 5) #no return type
	x*y
end

multiply(6)

multiply(6, 10)