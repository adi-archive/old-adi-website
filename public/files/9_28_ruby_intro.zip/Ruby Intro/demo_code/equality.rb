:s == :s
:s.equal?(:s)
"s" == "s"
"s".equal?("s")
1 == 1.0
1.eql?(1.0)