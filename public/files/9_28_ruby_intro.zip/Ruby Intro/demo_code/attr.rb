class Student
  @hw
  attr_reader :hw
end

s = Student.new
s.hw
s.hw = "lots" #fails

class Student
  attr_writer :v
end

s.hw
s.hw = "lots"
s.hw