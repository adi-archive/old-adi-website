class String
  def normalize
      self.capitalize.chop #string together methods
  end
end

x = "test"
x.normalize
x

class String
  def normalize!
      self.capitalize!.chop!
  end
end

x = "test"
x.normalize!
x